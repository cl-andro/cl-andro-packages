if [ ! -f /data/data/com.zk.clandro/files/home/.config/termux/clandro.properties ] && [ ! -e /data/data/com.zk.clandro/files/home/.cl-andro/clandro.properties ]; then
	mkdir -p /data/data/com.zk.clandro/files/home/.cl-andro
	cp /data/data/com.zk.clandro/files/usr/share/examples/termux/clandro.properties /data/data/com.zk.clandro/files/home/.cl-andro/
fi

bws completions fish | source

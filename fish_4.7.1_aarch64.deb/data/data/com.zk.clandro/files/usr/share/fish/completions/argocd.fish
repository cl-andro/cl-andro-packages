argocd completion fish | source

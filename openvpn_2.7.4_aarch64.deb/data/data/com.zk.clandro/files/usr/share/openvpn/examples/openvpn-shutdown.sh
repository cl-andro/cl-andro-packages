#!/data/data/com.zk.clandro/files/usr/bin/sh

# stop all openvpn processes

killall -TERM openvpn

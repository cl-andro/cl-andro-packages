cue completion fish | source

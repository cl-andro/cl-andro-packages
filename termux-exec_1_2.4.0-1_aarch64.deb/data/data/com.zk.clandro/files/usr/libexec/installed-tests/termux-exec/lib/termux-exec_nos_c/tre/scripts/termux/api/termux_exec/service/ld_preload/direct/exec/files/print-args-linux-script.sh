#!/data/data/com.zk.clandro/files/usr/bin/sh

echo "$@"

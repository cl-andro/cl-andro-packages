dagger completion fish | source

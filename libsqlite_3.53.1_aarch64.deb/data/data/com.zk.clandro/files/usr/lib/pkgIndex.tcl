package ifneeded sqlite3 3.53.1 [list load [file join $dir libsqlite3.53.1.so] Sqlite3]

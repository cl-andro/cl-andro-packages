#!/data/data/com.zk.clandro/files/usr/bin/bash
echo "Welcome to cl-andro (Cluster Family)!"
echo "Use the 'apt' command to manage packages."

if [ ! -f /data/data/com.zk.clandro/files/home/.config/cl-andro/clandro.properties ] && [ ! -e /data/data/com.zk.clandro/files/home/.cl-andro/clandro.properties ]; then
	mkdir -p /data/data/com.zk.clandro/files/home/.cl-andro
	cp /data/data/com.zk.clandro/files/usr/share/examples/clandro/clandro.properties /data/data/com.zk.clandro/files/home/.cl-andro/clandro.properties
fi

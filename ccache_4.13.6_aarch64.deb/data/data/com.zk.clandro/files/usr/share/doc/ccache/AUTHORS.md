Ccache was originally written by Andrew Tridgell and is currently
developed and maintained by Joel Rosdahl.

Ccache is a collective work with contributions from many people,
including:

-   Abubakar Nur Khalil

-   Aleksander Salwa

-   Alexander Falkenstern

-   Alexander Korsunsky

-   Alexander Lanin

-   Alexey Sheplyakov

-   Alexey Telishev

-   Alexey Tourbin

-   Alfred Landrum

-   Anders F Björklund

-   Andrea Bittau

-   Andreas Huber

-   Andreas Reischuck

-   Andrej Zhilenkov

-   André Klitzing

-   Andrew Boie

-   Andrew Hardin

-   Andrew Stubbs

-   Andrew Tridgell

-   Arne Hasselbring

-   Azat Khuzhin

-   Bernhard Bauer

-   Bernhard M. Wiedemann

-   Bin Li

-   Björn Jacke

-   Björn Svensson

-   Brendan Shanks

-   Breno Guimaraes

-   Byoungchan Lee

-   Carlo Cabrera

-   Chiaki Ishikawa

-   Chris AtLee

-   Chris Burr

-   Clemens Rabe

-   Clemens Wasser

-   Cristian Adam

-   Daniel Richtmann

-   David Givone

-   Dávid Péter Jánosa

-   Deepak Yadav

-   Diego Alonso

-   Doug Anderson

-   Edward Z. Yang

-   Enrico Seiler

-   Enrico Sorichetti

-   Erik Flodin

-   Evangelos Foutras

-   Evgeniy Isaev

-   Florin Trofin

-   Francois Marier

-   Gabriel Scherer

-   Geert Bosch

-   Geert Kloosterman

-   Gregor Jasny

-   Grigory Entin

-   Harsh Shandilya

-   Havard Graff

-   Henrique Ferreiro

-   Holger Hoffstätte

-   Hongli Lai

-   Huang Qin Jin

-   Icarus Sparry

-   Igor Pylypiv

-   Ivan Vaigult

-   Ivan Volnov

-   Jacob Young

-   Jiang Jiang

-   Jiri Hörner

-   Jiri Slaby

-   Jiulong Wang

-   J. Neuschäfer

-   Joel Galenson

-   Joel Rosdahl

-   John Basila

-   John Coiner

-   Jonathan Neuschäfer

-   Jon Bernard

-   Jonny Yu

-   Jon Petrissans

-   Jørgen P. Tjernø

-   Josh Soref

-   Josh Triplett

-   Juan Manuel Martinez Caamaño

-   Justin Lebar

-   Ka Ho Ng

-   Karl Chen

-   Kaspar Schleiser

-   Keith Buck

-   Khem Raj

-   Kira Bruneau

-   Kona Blend

-   Kovarththanan Rajaratnam

-   Kristian Sloth Lauszus

-   Lalit Chhabra

-   Lars Gustäbel

-   Laurent Bouhier

-   Leander Schulten

-   Leanid Chaika

-   Loïc Yhuel

-   Louis Caron

-   Luboš Luňák

-   Ludovic Henry

-   Maarten Maathuis

-   Maksym Sobolyev

-   Marius Zwicker

-   Mark Starovoytov

-   Martin Blanchard

-   Martin Ettl

-   Martin Pool

-   Martin Storsjö

-   Mathias De Maré

-   Matthias Kretz

-   Matt Johnston

-   Matt Whitlock

-   Max Winkler

-   Melven Roehrig-Zoellner

-   Michael Kruse

-   Michael Marineau

-   Michael Meeks

-   Michał Mirosław

-   Mihai Serban

-   Mike Blumenkrantz

-   Mike Frysinger

-   Mike Gulick

-   Mikhail Kolomeytsev

-   Mizuha Himuraki

-   Morten Engelhardt Olsen

-   Mostyn Bramley-Moore

-   Neil Mushell

-   Nicholas Hutchinson

-   Nick Sarnie

-   Nick Schultz

-   Norbert Lange

-   Oded Shimon

-   Oleg Sidorkin

-   Olle Liljenzin

-   Orgad Shaneh

-   Orion Poplawski

-   Owen Mann

-   Patrick von Reth

-   Paul Bunch

-   Paul Fultz II

-   Paul Griffith

-   Pavel Boldin

-   Pavol Sakac

-   Pawel Krysiak

-   Per Nordlöw

-   Peter Budai

-   Peter Steinberger

-   Petr Štetiar

-   Philippe Proulx

-   Philipp Gortan

-   Philipp Kolberg

-   Philipp Storz

-   Rafael Kitover

-   Raihaan Shouhell

-   Ramiro Polla

-   Robert Yang

-   Robin H. Johnson

-   Rolf Bjarne Kvinge

-   Romain Geissler

-   Rosen Penev

-   R. Voggenauer

-   Ryan Brown

-   Ryan Burns

-   Ryan Egesdahl

-   Sam Gross

-   Sam James

-   Sergei Trofimovich

-   Sergey Semushin

-   Silver Zachara

-   Steffen Dettmer

-   Steffen Winter

-   Stephan Rohmen

-   Steve Mokris

-   Stuart Henderson

-   Sumit Jamgade

-   Tadej Novak

-   Thomas Ferrand

-   Thomas Otto

-   Thomas Röfer

-   Timofei Kushnir

-   Tim Potter

-   Tobias Hieta

-   Tomasz Miąsko

-   Tom Hughes

-   Tom Stellard

-   Tor Arne Vestbø

-   Vadim Petrochenkov

-   Varun Sharma

-   Viktor Szépe

-   Vili Väinölä

-   Ville Skyttä

-   William S Fulton

-   Wilson Snyder

-   Xavier René-Corail

-   Yiding Jia

-   Yoshimasa Niwa

-   Yvan Janssens

Thanks!

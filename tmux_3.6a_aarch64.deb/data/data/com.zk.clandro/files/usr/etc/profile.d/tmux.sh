export TMUX_TMPDIR=/data/data/com.zk.clandro/files/usr/var/run

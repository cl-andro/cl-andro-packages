if [ ! -f /data/data/com.zk.clandro/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.zk.clandro/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.zk.clandro/files/home/.termux
	cp /data/data/com.zk.clandro/files/usr/share/examples/termux/termux.properties /data/data/com.zk.clandro/files/home/.termux/
fi

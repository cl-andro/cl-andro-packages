set(RESOLV_WRAPPER_LIBRARY /data/data/com.zk.clandro/files/usr/lib/libresolv_wrapper.so)

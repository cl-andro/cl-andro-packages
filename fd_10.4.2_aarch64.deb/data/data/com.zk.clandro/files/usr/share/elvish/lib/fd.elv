
use builtin;
use str;

set edit:completion:arg-completer[fd] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'fd'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'fd'= {
            cand --and 'Additional search patterns that need to be matched'
            cand -d 'Set maximum search depth (default: none)'
            cand --max-depth 'Set maximum search depth (default: none)'
            cand --min-depth 'Only show search results starting at the given depth.'
            cand --exact-depth 'Only show search results at the exact given depth'
            cand -E 'Exclude entries that match the given glob pattern'
            cand --exclude 'Exclude entries that match the given glob pattern'
            cand -t 'Filter by type: file (f), directory (d/dir), symlink (l), executable (x), empty (e), socket (s), pipe (p), char-device (c), block-device (b)'
            cand --type 'Filter by type: file (f), directory (d/dir), symlink (l), executable (x), empty (e), socket (s), pipe (p), char-device (c), block-device (b)'
            cand -e 'Filter by file extension'
            cand --extension 'Filter by file extension'
            cand -S 'Limit results based on the size of files'
            cand --size 'Limit results based on the size of files'
            cand --changed-within 'Filter by file modification time (newer than)'
            cand --changed-before 'Filter by file modification time (older than)'
            cand -o 'Filter by owning user and/or group'
            cand --owner 'Filter by owning user and/or group'
            cand --format 'Print results according to template'
            cand -x 'Execute a command for each search result'
            cand --exec 'Execute a command for each search result'
            cand -X 'Execute a command with all search results at once'
            cand --exec-batch 'Execute a command with all search results at once'
            cand --batch-size 'Max number of arguments to run as a batch size with -X'
            cand --ignore-file 'Add a custom ignore-file in ''.gitignore'' format'
            cand -c 'When to use colors'
            cand --color 'When to use colors'
            cand --hyperlink 'Add hyperlinks to output paths'
            cand --ignore-contain 'Ignore directories containing the named entry'
            cand -j 'Set number of threads to use for searching & executing (default: number of available CPU cores)'
            cand --threads 'Set number of threads to use for searching & executing (default: number of available CPU cores)'
            cand --max-buffer-time 'Milliseconds to buffer before streaming search results to console'
            cand --max-results 'Limit the number of search results'
            cand -C 'Change current working directory'
            cand --base-directory 'Change current working directory'
            cand --path-separator 'Set path separator when printing file paths'
            cand --search-path 'Provides paths to search as an alternative to the positional <path> argument'
            cand --strip-cwd-prefix 'By default, relative paths are prefixed with ''./'' when -x/--exec, -X/--exec-batch, or -0/--print0 are given, to reduce the risk of a path starting with ''-'' being treated as a command line option. Use this flag to change this behavior. If this flag is used without a value, it is equivalent to passing "always"'
            cand --gen-completions 'gen-completions'
            cand -H 'Search hidden files and directories'
            cand --hidden 'Search hidden files and directories'
            cand --no-hidden 'Overrides --hidden'
            cand -I 'Do not respect .(git|fd)ignore files'
            cand --no-ignore 'Do not respect .(git|fd)ignore files'
            cand --ignore 'Overrides --no-ignore'
            cand --no-ignore-vcs 'Do not respect .gitignore files'
            cand --ignore-vcs 'Overrides --no-ignore-vcs'
            cand --no-require-git 'Do not require a git repository to respect gitignores. By default, fd will only respect global gitignore rules, .gitignore rules, and local exclude rules if fd detects that you are searching inside a git repository. This flag allows you to relax this restriction such that fd will respect all git related ignore rules regardless of whether you''re searching in a git repository or not'
            cand --require-git 'Overrides --no-require-git'
            cand --no-ignore-parent 'Do not respect .(git|fd)ignore files in parent directories'
            cand --no-global-ignore-file 'Do not respect the global ignore file'
            cand -u 'Unrestricted search, alias for ''--no-ignore --hidden'''
            cand --unrestricted 'Unrestricted search, alias for ''--no-ignore --hidden'''
            cand -s 'Case-sensitive search (default: smart case)'
            cand --case-sensitive 'Case-sensitive search (default: smart case)'
            cand -i 'Case-insensitive search (default: smart case)'
            cand --ignore-case 'Case-insensitive search (default: smart case)'
            cand -g 'Glob-based search (default: regular expression)'
            cand --glob 'Glob-based search (default: regular expression)'
            cand --regex 'Regular-expression based search (default)'
            cand -F 'Treat pattern as literal string stead of regex'
            cand --fixed-strings 'Treat pattern as literal string stead of regex'
            cand -a 'Show absolute instead of relative paths'
            cand --absolute-path 'Show absolute instead of relative paths'
            cand --relative-path 'Overrides --absolute-path'
            cand -l 'Use a long listing format with file metadata'
            cand --list-details 'Use a long listing format with file metadata'
            cand -L 'Follow symbolic links'
            cand --follow 'Follow symbolic links'
            cand --no-follow 'Overrides --follow'
            cand -p 'Search full abs. path (default: filename only)'
            cand --full-path 'Search full abs. path (default: filename only)'
            cand -0 'Separate search results by the null character'
            cand --print0 'Separate search results by the null character'
            cand --prune 'Do not traverse into directories that match the search criteria. If you want to exclude specific directories, use the ''--exclude=…'' option'
            cand -1 'Limit search to a single result'
            cand -q 'Print nothing, exit code 0 if match found, 1 otherwise'
            cand --quiet 'Print nothing, exit code 0 if match found, 1 otherwise'
            cand --show-errors 'Show filesystem errors'
            cand --one-file-system 'By default, fd will traverse the file system tree as far as other options dictate. With this flag, fd ensures that it does not descend into a different file system than the one it started in. Comparable to the -mount or -xdev filters of find(1)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}

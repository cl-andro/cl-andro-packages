#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/com.zk.clandro/files/usr/lib"
XSLT_LIBS="-lxslt -lxml2"
XSLT_PRIVATE_LIBS=" -lm"
XSLT_INCLUDEDIR="-I/data/data/com.zk.clandro/files/usr/include"
MODULE_VERSION="xslt-1.1.45"

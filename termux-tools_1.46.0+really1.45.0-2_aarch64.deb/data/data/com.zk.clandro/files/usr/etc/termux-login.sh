##
## This script is sourced by /data/data/com.zk.clandro/files/usr/bin/login before executing shell.
##
